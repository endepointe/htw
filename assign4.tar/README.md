Start of the hunt the wumpus repo
