/****************************************************************************
 * Filename: event.cpp
 * Author: Alvin Johns
 * Date: Nov 21, 2019
 * Desc: sets default constructor for each event type
 ***************************************************************************/

#include "event.h"
#include <string>
using namespace std;

Event::Event() {
	// doesnt do anything
}
